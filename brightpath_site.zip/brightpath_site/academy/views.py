from functools import wraps

from django.contrib import messages
from django.contrib.auth.views import LoginView, redirect_to_login
from django.core.exceptions import PermissionDenied
from django.db.models import Q
from django.http import FileResponse, Http404
from django.shortcuts import get_object_or_404, redirect, render

from .forms import EnquiryForm, StudentLoginForm
from .models import (
    Assignment, Course, Exam, Faculty, Lesson, Module, Notice, Testimonial, University,
)


# ------------------------------------------------------------------ public
def home(request):
    courses = Course.objects.filter(is_active=True).select_related("university")
    groups = [
        (label, courses.filter(category=key))
        for key, label in Course.CATEGORY_CHOICES
    ]
    return render(request, "academy/home.html", {
        "groups": [(l, qs) for l, qs in groups if qs],
        "universities": University.objects.all()[:3],
        "testimonials": Testimonial.objects.filter(is_active=True)[:6],
        "notices": Notice.objects.filter(is_active=True, is_public=True)[:4],
    })


def about(request):
    return render(request, "academy/about.html", {"faculty": Faculty.objects.all()})


def courses(request):
    qs = Course.objects.filter(is_active=True).select_related("university")
    cat = request.GET.get("category", "")
    if cat in dict(Course.CATEGORY_CHOICES):
        qs = qs.filter(category=cat)
    return render(request, "academy/courses.html", {
        "courses": qs, "active_cat": cat, "categories": Course.CATEGORY_CHOICES,
    })


def course_detail(request, slug):
    course = get_object_or_404(Course, slug=slug, is_active=True)
    return render(request, "academy/course_detail.html", {"course": course})


def university(request):
    return render(request, "academy/university.html", {"universities": University.objects.all()})


def contact(request):
    initial = {}
    if request.GET.get("course"):
        c = Course.objects.filter(slug=request.GET["course"]).first()
        if c:
            initial["course"] = c
    form = EnquiryForm(request.POST or None, initial=initial)
    if request.method == "POST" and form.is_valid():
        form.save()
        messages.success(request, "Thank you. We have received your enquiry and will call you soon.")
        return redirect("contact")
    return render(request, "academy/contact.html", {"form": form})


class StudentLogin(LoginView):
    template_name = "academy/login.html"
    authentication_form = StudentLoginForm
    redirect_authenticated_user = True


# ------------------------------------------------------------ access rules
def _profile(user):
    return getattr(user, "student_profile", None)


def can_access(user, course):
    """Staff can preview everything. A student can open ONLY their own course."""
    if not user.is_authenticated:
        return False
    if user.is_staff:
        return True
    p = _profile(user)
    return bool(p and p.is_active and p.course_id == course.id)


def student_required(view):
    @wraps(view)
    def wrapper(request, *args, **kwargs):
        if not request.user.is_authenticated:
            return redirect_to_login(request.get_full_path())
        p = _profile(request.user)
        if request.user.is_staff and not p:
            return redirect("admin:index")
        if not p:
            return render(request, "academy/no_access.html", {"reason": "no_course"}, status=403)
        if not p.is_active:
            return render(request, "academy/no_access.html", {"reason": "paused"}, status=403)
        return view(request, *args, **kwargs)
    return wrapper


# ------------------------------------------------------------------ portal
@student_required
def portal(request):
    p = _profile(request.user)
    course = p.course
    notices = Notice.objects.filter(is_active=True).filter(Q(course=course) | Q(course__isnull=True))[:5]
    lesson_count = Lesson.objects.filter(module__course=course, is_published=True).count()
    return render(request, "academy/portal.html", {
        "profile": p,
        "course": course,
        "notices": notices,
        "assignments": Assignment.objects.filter(course=course, is_published=True),
        "exams": Exam.objects.filter(course=course, is_published=True),
        "lesson_count": lesson_count,
    })


@student_required
def portal_course(request):
    course = _profile(request.user).course
    modules = Module.objects.filter(course=course).prefetch_related("lessons")
    data = []
    for m in modules:
        ls = [l for l in m.lessons.all() if l.is_published]
        if ls:
            data.append((m, ls))
    return render(request, "academy/portal_course.html", {"course": course, "modules": data})


@student_required
def lesson_view(request, pk):
    lesson = get_object_or_404(Lesson.objects.select_related("module__course"), pk=pk, is_published=True)
    course = lesson.module.course
    if not can_access(request.user, course):
        raise PermissionDenied
    all_lessons = list(
        Lesson.objects.filter(module__course=course, is_published=True)
        .order_by("module__order", "module_id", "order", "id")
    )
    idx = next((i for i, l in enumerate(all_lessons) if l.pk == lesson.pk), 0)
    return render(request, "academy/lesson.html", {
        "lesson": lesson, "course": course,
        "prev": all_lessons[idx - 1] if idx > 0 else None,
        "next": all_lessons[idx + 1] if idx < len(all_lessons) - 1 else None,
        "viewer_name": request.user.get_full_name() or request.user.username,
    })


FILE_SOURCES = {
    "lesson-file": (Lesson, "file"),
    "lesson-video": (Lesson, "video_file"),
    "assignment": (Assignment, "file"),
    "exam": (Exam, "file"),
}


def protected_file(request, kind, pk):
    """The ONLY way private files are served: login + right course required."""
    if not request.user.is_authenticated:
        return redirect_to_login(request.get_full_path())
    source = FILE_SOURCES.get(kind)
    if not source:
        raise Http404
    model, field = source
    obj = get_object_or_404(model, pk=pk)
    if not request.user.is_staff and not getattr(obj, "is_published", True):
        raise Http404
    if not can_access(request.user, obj.get_course()):
        raise PermissionDenied
    f = getattr(obj, field)
    if not f:
        raise Http404
    response = FileResponse(f.open("rb"), as_attachment=request.GET.get("dl") == "1")
    response["Cache-Control"] = "private, no-store"
    response["X-Content-Type-Options"] = "nosniff"
    return response
