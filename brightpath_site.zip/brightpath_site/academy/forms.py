from django import forms
from django.contrib.auth.forms import AuthenticationForm

from .models import Enquiry


class StudentLoginForm(AuthenticationForm):
    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.fields["username"].label = "Student ID"
        self.fields["username"].widget.attrs.update(
            {"placeholder": "Your Student ID", "autocomplete": "username", "autofocus": True}
        )
        self.fields["password"].widget.attrs.update(
            {"placeholder": "Password", "autocomplete": "current-password"}
        )
        self.error_messages["invalid_login"] = (
            "Student ID or password is incorrect. Check both and try again."
        )


class EnquiryForm(forms.ModelForm):
    class Meta:
        model = Enquiry
        fields = ["name", "phone", "email", "course", "message"]
        widgets = {
            "name": forms.TextInput(attrs={"placeholder": "Your name"}),
            "phone": forms.TextInput(attrs={"placeholder": "Mobile number", "inputmode": "tel"}),
            "email": forms.EmailInput(attrs={"placeholder": "Email (optional)"}),
            "message": forms.Textarea(attrs={"rows": 4, "placeholder": "What would you like to know?"}),
        }

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        from .models import Course
        self.fields["course"].queryset = Course.objects.filter(is_active=True)
        self.fields["course"].empty_label = "Course you are interested in"
        self.fields["course"].required = False
