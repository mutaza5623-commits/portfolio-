from .models import SiteSettings


def site(request):
    try:
        return {"site": SiteSettings.load()}
    except Exception:
        # e.g. before migrations have been run
        return {"site": None}
