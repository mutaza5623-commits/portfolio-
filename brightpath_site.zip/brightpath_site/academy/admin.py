from django.contrib import admin
from django.contrib.auth.admin import UserAdmin as BaseUserAdmin
from django.contrib.auth.models import User

from .models import (
    Assignment, Course, Enquiry, Exam, Faculty, Lesson, Module, Notice,
    SiteSettings, StudentProfile, Testimonial, University,
)


@admin.register(SiteSettings)
class SiteSettingsAdmin(admin.ModelAdmin):
    def has_add_permission(self, request):
        return not SiteSettings.objects.exists()

    def has_delete_permission(self, request, obj=None):
        return False


@admin.register(University)
class UniversityAdmin(admin.ModelAdmin):
    list_display = ("name", "short_name", "order")


class ModuleInline(admin.TabularInline):
    model = Module
    extra = 1


@admin.register(Course)
class CourseAdmin(admin.ModelAdmin):
    list_display = ("title", "code", "category", "university", "duration", "is_active", "order")
    list_filter = ("category", "is_active", "university")
    list_editable = ("is_active", "order")
    prepopulated_fields = {"slug": ("title",)}
    search_fields = ("title", "code")
    inlines = [ModuleInline]


class LessonInline(admin.StackedInline):
    model = Lesson
    extra = 1


@admin.register(Module)
class ModuleAdmin(admin.ModelAdmin):
    list_display = ("title", "course", "order")
    list_filter = ("course",)
    inlines = [LessonInline]


@admin.register(Lesson)
class LessonAdmin(admin.ModelAdmin):
    list_display = ("title", "module", "lesson_type", "order", "is_published")
    list_filter = ("module__course", "lesson_type", "is_published")
    search_fields = ("title",)


@admin.register(Assignment)
class AssignmentAdmin(admin.ModelAdmin):
    list_display = ("title", "course", "due_date", "is_published")
    list_filter = ("course", "is_published")


@admin.register(Exam)
class ExamAdmin(admin.ModelAdmin):
    list_display = ("title", "course", "exam_date", "is_published")
    list_filter = ("course", "is_published")


@admin.register(Notice)
class NoticeAdmin(admin.ModelAdmin):
    list_display = ("title", "course", "created", "is_public", "is_active")
    list_filter = ("course", "is_public", "is_active")


@admin.register(Faculty)
class FacultyAdmin(admin.ModelAdmin):
    list_display = ("name", "role", "order")


@admin.register(Testimonial)
class TestimonialAdmin(admin.ModelAdmin):
    list_display = ("name", "course", "is_active")


@admin.register(Enquiry)
class EnquiryAdmin(admin.ModelAdmin):
    list_display = ("name", "phone", "course", "created", "handled")
    list_filter = ("handled", "course")
    list_editable = ("handled",)
    search_fields = ("name", "phone")


class StudentProfileInline(admin.StackedInline):
    model = StudentProfile
    can_delete = False
    extra = 1
    max_num = 1
    verbose_name = "Student details (choose the ONE course this ID can open)"


admin.site.unregister(User)


@admin.register(User)
class UserAdmin(BaseUserAdmin):
    inlines = [StudentProfileInline]
    list_display = ("username", "first_name", "last_name", "student_course", "is_active")
    list_filter = ("is_active", "is_staff", "student_profile__course")

    @admin.display(description="Course")
    def student_course(self, obj):
        p = getattr(obj, "student_profile", None)
        return p.course if p else "-"


@admin.register(StudentProfile)
class StudentProfileAdmin(admin.ModelAdmin):
    list_display = ("user", "enrollment_no", "course", "phone", "joined_on", "is_active")
    list_filter = ("course", "is_active")
    search_fields = ("user__username", "user__first_name", "enrollment_no", "phone")
