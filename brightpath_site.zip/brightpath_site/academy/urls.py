from django.contrib.auth.views import LogoutView
from django.urls import path

from . import views

urlpatterns = [
    path("", views.home, name="home"),
    path("about/", views.about, name="about"),
    path("courses/", views.courses, name="courses"),
    path("courses/<slug:slug>/", views.course_detail, name="course_detail"),
    path("university/", views.university, name="university"),
    path("contact/", views.contact, name="contact"),
    path("login/", views.StudentLogin.as_view(), name="login"),
    path("logout/", LogoutView.as_view(), name="logout"),
    path("portal/", views.portal, name="portal"),
    path("portal/course/", views.portal_course, name="portal_course"),
    path("portal/lesson/<int:pk>/", views.lesson_view, name="lesson"),
    path("portal/file/<str:kind>/<int:pk>/", views.protected_file, name="protected_file"),
]
