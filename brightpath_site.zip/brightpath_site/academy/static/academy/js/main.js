(function () {
  var burger = document.querySelector(".burger");
  var menu = document.getElementById("menu");
  if (!burger || !menu) return;
  burger.addEventListener("click", function () {
    var open = menu.classList.toggle("open");
    burger.setAttribute("aria-expanded", open ? "true" : "false");
  });
})();
