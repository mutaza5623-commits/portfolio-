import re

from django.conf import settings
from django.contrib.auth.models import User
from django.core.files.storage import FileSystemStorage
from django.db import models
from django.urls import reverse


def private_storage():
    """Course files live outside MEDIA_ROOT so they can't be opened by URL."""
    return FileSystemStorage(location=settings.PRIVATE_MEDIA_ROOT)


def lines(text):
    return [l.strip() for l in (text or "").splitlines() if l.strip()]


class SiteSettings(models.Model):
    """One editable record that controls the public website text."""

    academy_name = models.CharField(max_length=120, default="Bright Path Academy")
    tagline = models.CharField(max_length=200, default="सीखिए, आगे बढ़िए")
    logo = models.ImageField(upload_to="branding/", blank=True)
    hero_title = models.CharField(
        max_length=200, default="Computer courses that take you somewhere"
    )
    hero_subtitle = models.TextField(
        default="University-recognised diplomas and practical short-term certificates, "
        "with a private learning portal for every enrolled student."
    )
    about_text = models.TextField(
        default="Bright Path Academy offers computer education through diploma, "
        "post graduate diploma and short-term certificate programs."
    )
    mission = models.TextField(blank=True)
    phone = models.CharField(max_length=30, blank=True)
    whatsapp = models.CharField(
        max_length=20, blank=True, help_text="Digits only with country code, e.g. 919876543210"
    )
    email = models.EmailField(blank=True)
    address = models.TextField(blank=True)
    map_embed_url = models.URLField(blank=True, help_text="Google Maps embed URL (optional)")
    facebook = models.URLField(blank=True)
    instagram = models.URLField(blank=True)
    youtube = models.URLField(blank=True)
    office_hours = models.CharField(max_length=120, blank=True, default="Mon - Sat, 9 AM - 6 PM")

    class Meta:
        verbose_name = "Site settings"
        verbose_name_plural = "Site settings"

    def __str__(self):
        return "Website settings"

    def save(self, *args, **kwargs):
        self.pk = 1
        super().save(*args, **kwargs)

    @classmethod
    def load(cls):
        obj, _ = cls.objects.get_or_create(pk=1)
        return obj


class University(models.Model):
    name = models.CharField(max_length=200)
    short_name = models.CharField(max_length=40, blank=True)
    logo = models.ImageField(upload_to="universities/", blank=True)
    about = models.TextField(blank=True)
    highlights = models.TextField(
        blank=True, help_text="One point per line (approvals, recognitions, etc.)"
    )
    website = models.URLField(blank=True)
    order = models.PositiveIntegerField(default=0)

    class Meta:
        ordering = ["order", "name"]
        verbose_name_plural = "Universities"

    def __str__(self):
        return self.name

    @property
    def highlight_list(self):
        return lines(self.highlights)


class Course(models.Model):
    DIPLOMA = "diploma"
    PGDIP = "pgdiploma"
    CERT = "certificate"
    CATEGORY_CHOICES = [
        (DIPLOMA, "Diploma"),
        (PGDIP, "Post Graduate Diploma"),
        (CERT, "Short-term Certificate"),
    ]

    title = models.CharField(max_length=160)
    code = models.CharField(max_length=20, blank=True, help_text="e.g. DCA, PGDCA")
    slug = models.SlugField(unique=True)
    category = models.CharField(max_length=20, choices=CATEGORY_CHOICES, default=CERT)
    university = models.ForeignKey(
        University, null=True, blank=True, on_delete=models.SET_NULL,
        help_text="Leave empty for the academy's own certificate courses",
    )
    duration = models.CharField(max_length=60, blank=True, help_text="e.g. 6 months")
    fee = models.CharField(max_length=60, blank=True, help_text="Shown publicly, e.g. Rs. 8,000")
    eligibility = models.CharField(max_length=200, blank=True)
    short_description = models.CharField(max_length=240, blank=True)
    description = models.TextField(blank=True)
    syllabus = models.TextField(blank=True, help_text="One topic per line")
    image = models.ImageField(upload_to="courses/", blank=True)
    is_active = models.BooleanField(default=True)
    order = models.PositiveIntegerField(default=0)

    class Meta:
        ordering = ["order", "title"]

    def __str__(self):
        return self.title

    def get_absolute_url(self):
        return reverse("course_detail", args=[self.slug])

    @property
    def syllabus_list(self):
        return lines(self.syllabus)

    @property
    def awarded_by(self):
        return self.university.name if self.university else "Bright Path Academy"


class StudentProfile(models.Model):
    """Links a login to exactly ONE course. This is what locks the content."""

    user = models.OneToOneField(User, on_delete=models.CASCADE, related_name="student_profile")
    course = models.ForeignKey(Course, on_delete=models.PROTECT, related_name="students")
    enrollment_no = models.CharField(max_length=40, blank=True)
    phone = models.CharField(max_length=20, blank=True)
    photo = models.ImageField(upload_to="students/", blank=True)
    joined_on = models.DateField(auto_now_add=True)
    is_active = models.BooleanField(
        default=True, help_text="Untick to pause this student's access (e.g. fees pending)"
    )

    def __str__(self):
        return f"{self.user.get_full_name() or self.user.username} - {self.course}"


class Module(models.Model):
    course = models.ForeignKey(Course, on_delete=models.CASCADE, related_name="modules")
    title = models.CharField(max_length=160)
    order = models.PositiveIntegerField(default=0)

    class Meta:
        ordering = ["order", "id"]

    def __str__(self):
        return f"{self.course.code or self.course.title} / {self.title}"


class Lesson(models.Model):
    VIDEO, NOTES, OTHER = "video", "notes", "other"
    TYPE_CHOICES = [(VIDEO, "Video"), (NOTES, "Notes / PDF"), (OTHER, "Other")]

    module = models.ForeignKey(Module, on_delete=models.CASCADE, related_name="lessons")
    title = models.CharField(max_length=160)
    lesson_type = models.CharField(max_length=10, choices=TYPE_CHOICES, default=VIDEO)
    description = models.TextField(blank=True)
    video_url = models.URLField(
        blank=True, help_text="YouTube (unlisted) or Vimeo link. Best for long videos."
    )
    video_file = models.FileField(upload_to="videos/", storage=private_storage, blank=True)
    file = models.FileField(upload_to="notes/", storage=private_storage, blank=True)
    order = models.PositiveIntegerField(default=0)
    is_published = models.BooleanField(default=True)

    class Meta:
        ordering = ["module__order", "module_id", "order", "id"]

    def __str__(self):
        return self.title

    def get_course(self):
        return self.module.course

    @property
    def embed_url(self):
        u = self.video_url
        m = re.search(r"(?:youtu\.be/|v=|embed/)([\w-]{11})", u)
        if m:
            return f"https://www.youtube-nocookie.com/embed/{m.group(1)}?rel=0&modestbranding=1"
        m = re.search(r"vimeo\.com/(\d+)", u)
        if m:
            return f"https://player.vimeo.com/video/{m.group(1)}"
        return u


class Assignment(models.Model):
    course = models.ForeignKey(Course, on_delete=models.CASCADE, related_name="assignments")
    title = models.CharField(max_length=160)
    description = models.TextField(blank=True)
    file = models.FileField(upload_to="assignments/", storage=private_storage, blank=True)
    due_date = models.DateField(null=True, blank=True)
    is_published = models.BooleanField(default=True)

    class Meta:
        ordering = ["due_date", "id"]

    def __str__(self):
        return self.title

    def get_course(self):
        return self.course


class Exam(models.Model):
    course = models.ForeignKey(Course, on_delete=models.CASCADE, related_name="exams")
    title = models.CharField(max_length=160)
    exam_date = models.DateField(null=True, blank=True)
    duration = models.CharField(max_length=40, blank=True, help_text="e.g. 2 hours")
    instructions = models.TextField(blank=True)
    file = models.FileField(
        upload_to="exams/", storage=private_storage, blank=True,
        help_text="Syllabus / admit card / paper (optional)",
    )
    is_published = models.BooleanField(default=True)

    class Meta:
        ordering = ["exam_date", "id"]

    def __str__(self):
        return self.title

    def get_course(self):
        return self.course


class Notice(models.Model):
    course = models.ForeignKey(
        Course, null=True, blank=True, on_delete=models.CASCADE,
        help_text="Leave empty to show to all students",
    )
    title = models.CharField(max_length=160)
    body = models.TextField(blank=True)
    created = models.DateTimeField(auto_now_add=True)
    is_public = models.BooleanField(default=False, help_text="Also show on the public home page")
    is_active = models.BooleanField(default=True)

    class Meta:
        ordering = ["-created"]

    def __str__(self):
        return self.title


class Faculty(models.Model):
    name = models.CharField(max_length=120)
    role = models.CharField(max_length=120, blank=True)
    bio = models.CharField(max_length=240, blank=True)
    photo = models.ImageField(upload_to="faculty/", blank=True)
    order = models.PositiveIntegerField(default=0)

    class Meta:
        ordering = ["order", "name"]
        verbose_name_plural = "Faculty"

    def __str__(self):
        return self.name


class Testimonial(models.Model):
    name = models.CharField(max_length=120)
    course = models.CharField(max_length=120, blank=True)
    text = models.TextField()
    photo = models.ImageField(upload_to="testimonials/", blank=True)
    is_active = models.BooleanField(default=True)

    def __str__(self):
        return self.name


class Enquiry(models.Model):
    name = models.CharField(max_length=120)
    phone = models.CharField(max_length=20)
    email = models.EmailField(blank=True)
    course = models.ForeignKey(Course, null=True, blank=True, on_delete=models.SET_NULL)
    message = models.TextField(blank=True)
    created = models.DateTimeField(auto_now_add=True)
    handled = models.BooleanField(default=False)

    class Meta:
        ordering = ["-created"]
        verbose_name_plural = "Enquiries"

    def __str__(self):
        return f"{self.name} ({self.phone})"
