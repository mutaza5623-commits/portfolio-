# Bright Path Academy - Website + Student Portal (Django + MySQL)

## 1. Setup (one time)
```
python -m venv venv
venv\Scripts\activate          (Windows)   |   source venv/bin/activate   (Linux/Mac)
pip install -r requirements.txt
```
Create an empty MySQL database:
```
CREATE DATABASE brightpath CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
```
Set DB_NAME, DB_USER, DB_PASSWORD, DB_HOST as environment variables (see .env.example).

## 2. Create tables and admin
```
python manage.py makemigrations academy
python manage.py migrate
python manage.py createsuperuser
python manage.py runserver
```
Site: http://127.0.0.1:8000/   Admin: http://127.0.0.1:8000/admin/

(For a quick test without MySQL: set USE_SQLITE=1)

## 3. Fill the site (Admin panel)
1. Site settings: logo, name, phone, address, hero text.
2. Universities: add IASECT / Rabindranath Tagore University details and logo.
3. Courses: DCA, PGDCA and your certificate courses. Then add Modules -> Lessons (video link / video file / notes PDF).
4. Assignments, Exams, Notices, Faculty, Testimonials.
Everything on the public site can be edited or replaced here at any time.

## 4. Give a student a login
Admin -> Users -> Add user (Student ID + password). On the same page, under
"Student details", pick the ONE course. That ID can open only that course.
To pause access, untick "Is active" on the student details.

## 5. How content is protected
Notes, videos, assignments and exam files are saved in `private_media/`, which
has no public URL. They are served only through `/portal/file/...` after checking
that the logged-in student's course matches the file's course.
Tip: for long videos, upload as *Unlisted* on YouTube/Vimeo and paste the link.

## 6. Going live
Set DJANGO_DEBUG=0, DJANGO_SECRET_KEY, DJANGO_ALLOWED_HOSTS.
Run `python manage.py collectstatic`, serve with gunicorn + nginx (HTTPS).
Serve /media/ (public images only) from nginx. NEVER expose private_media/.
