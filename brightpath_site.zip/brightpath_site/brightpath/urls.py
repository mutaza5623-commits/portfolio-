from django.conf import settings
from django.conf.urls.static import static
from django.contrib import admin
from django.urls import include, path

admin.site.site_header = "Bright Path Academy - Admin"
admin.site.site_title = "Bright Path Admin"
admin.site.index_title = "Manage website, courses and students"

urlpatterns = [
    path("admin/", admin.site.urls),
    path("", include("academy.urls")),
]

# Public media only (logo, photos). Private course files are NOT here.
if settings.DEBUG:
    urlpatterns += static(settings.MEDIA_URL, document_root=settings.MEDIA_ROOT)
